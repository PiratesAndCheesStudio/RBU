//silencers
#define jtog_rbu_silencer ["muzzle_snds_H", "muzzle_snds_L", "muzzle_snds_M", "muzzle_snds_B", "muzzle_snds_H_MG"];

//blacklist of units
#define jtog_rbu_unit_blacklist ["ibr_afr_cop"];
